
// Header
const header = {
    "alg": "RS256",
    "typ": "JWT"
}

module.exports = { header }
